import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import common.OpenPdf;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import com.itextpdf.text.pdf.PdfWriter;

import dao.BillDao;
import dao.CategoryDao;
import dao.ProductDao;
import model.Bill;
import model.Category;
import model.Product;
import model.User;

import javax.swing.JSpinner;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSpinner;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

public class PlaceOrder {
	public static int billId = 1;
	public static float grandTotal = 0;
	public static float productPrice = 0;
	public static float productTotal = 0;
	public String emailPattern = "^[a-zA-Z0-9]+[@]+[a-zA-Z0-9]+[.]+[a-zA-Z0-9]+$";
	public String mobileNumberPattern = "[0-9]*$";
	public String userEmail;
	private static JTextField txtSearch;
	private static JTextField txtProName;
	private static JTextField txtPrice;
	private static JTextField txtTotal;
	
	public static void clearProductFields(JButton btnAddToCart,JSpinner spinner) {
		txtProName.setText("");
		txtPrice.setText("");
		spinner.setValue(1);
		txtTotal.setText("");
		btnAddToCart.setEnabled(false);
	}
	
	public static void  productNameByCategory(String category, JTable j) {
		DefaultTableModel dtm = (DefaultTableModel) j.getModel();
        dtm.setRowCount(0);
        ArrayList<Product> list1 = ProductDao.getAllRecordsByCategory(category);
        Iterator<Product> itr1 = list1.iterator();
        while(itr1.hasNext()) {
        	Product productObj = itr1.next();
        	dtm.addRow(new Object[] {productObj.getName()});
        }
	}
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void PlaceOrder(JFrame hf, String email) {
		JFrame f = new JFrame();
		f.getContentPane().setBackground(new Color(229, 217, 205));

		JLabel lblBill = new JLabel("--");
		lblBill.setBounds(114, 109, 46, 14);
		f.getContentPane().add(lblBill);
		

		
		f.setLocationByPlatform(true);
		f.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 14));

		f.getContentPane().setLayout(null);
		
		JLabel lblPlaceOrder = new JLabel("Place Order");
		lblPlaceOrder.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblPlaceOrder.setBounds(10, 11, 150, 20);
		f.getContentPane().add(lblPlaceOrder);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hf.setEnabled(true);
				f.dispose();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\close.png"));
		btnNewButton.setBounds(1240, 11, 30, 30);
		f.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Category");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel.setBounds(202, 80, 100, 14);
		f.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Search");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(202, 170, 74, 14);
		f.getContentPane().add(lblNewLabel_1);
		
		txtSearch = new JTextField();
		txtSearch.setBounds(202, 195, 250, 20);
		f.getContentPane().add(txtSearch);
		txtSearch.setColumns(10);
		
		DefaultTableModel header = new DefaultTableModel();
		header.addColumn("Name");
		JTable j = new JTable(header);
		j.setBackground(new Color(255, 255, 255));
        JScrollPane scrollPane = new JScrollPane(j);
        
		scrollPane.setBounds(202,280,250,340);
		f.getContentPane().add(scrollPane);
		
		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(549, 80, 54, 14);
		f.getContentPane().add(lblNewLabel_2);
		
		txtProName = new JTextField();
		txtProName.setBounds(549, 106, 250, 20);
		f.getContentPane().add(txtProName);
		txtProName.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Quantity");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3.setBounds(549, 170, 123, 14);
		f.getContentPane().add(lblNewLabel_3);
		
		JSpinner spinner = new JSpinner();
		spinner.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e) {
				int quantity = (Integer) spinner.getValue();
				if(quantity <= 1) {
					spinner.setValue(1);
					quantity = 1;
				}
				productTotal = productPrice * quantity;
				txtTotal.setText(String.valueOf("$"+productTotal));
			}
		});
		spinner.setBounds(549, 195, 250, 20);
		f.getContentPane().add(spinner);
		
		JLabel lblNewLabel_4 = new JLabel("Price");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_4.setBounds(896, 80, 46, 14);
		f.getContentPane().add(lblNewLabel_4);
		
		txtPrice = new JTextField();
		txtPrice.setBounds(896, 106, 250, 20);
		f.getContentPane().add(txtPrice);
		txtPrice.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Total");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_5.setBounds(896, 170, 54, 14);
		f.getContentPane().add(lblNewLabel_5);
		
		txtTotal = new JTextField();
		txtTotal.setColumns(10);
		txtTotal.setBounds(896, 195, 250, 20);
		f.getContentPane().add(txtTotal);
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.setBackground(new Color(255, 255, 255));
		btnRefresh.setBounds(549, 237, 89, 23);
		f.getContentPane().add(btnRefresh);
		
		JButton btnAddToCart = new JButton("Add To Cart");
		btnAddToCart.setBackground(new Color(255, 255, 255));
		btnAddToCart.setBounds(996, 237, 150, 23);
		f.getContentPane().add(btnAddToCart);
		
		JLabel lblGrandTotal = new JLabel("$0");
		lblGrandTotal.setBounds(640, 661, 46, 14);
		f.getContentPane().add(lblGrandTotal);
		
		DefaultTableModel header2 = new DefaultTableModel();
		header2.addColumn("Name");
		header2.addColumn("Price");
		header2.addColumn("Quantity");
		header2.addColumn("Total");
		JTable j2 = new JTable(header2);
		j2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index = j2.getSelectedRow();
				int a = JOptionPane.showConfirmDialog(null, "Do you want to remove this product?","Select",JOptionPane.YES_NO_OPTION);
				if (a == 0) {
					TableModel model = j2.getModel();
					String total = model.getValueAt(index, 3).toString();
					total = total.replace("$", "");
					grandTotal = grandTotal - Float.parseFloat(total);
					lblGrandTotal.setText("$"+String.valueOf(grandTotal));
					((DefaultTableModel) j2.getModel()).removeRow(index);
					PlaceOrder(hf, email);
					f.dispose();
				}
			}
		});
		j2.setBackground(new Color(255, 255, 255));
        JScrollPane scrollPane2 = new JScrollPane(j2);
        
		scrollPane2.setBounds(549,280,597,340);
		f.getContentPane().add(scrollPane2);
		
		JLabel lblNewLabel_6 = new JLabel("Grand Total: ");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_6.setBounds(549, 660, 105, 14);
		f.getContentPane().add(lblNewLabel_6);
		
		JButton btnGenerateBillPrint = new JButton("Generate Bill & Print");
		btnGenerateBillPrint.setBackground(new Color(255, 255, 255));
		btnGenerateBillPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BillDao bd = new BillDao();
				SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
				Date date = new Date();
				String todayDate = df.format(date);
				String total = String.valueOf(grandTotal);
				String createdBy = bd.getName(email);
				Bill bill = new Bill();
				bill.setId(billId);
				bill.setDate(todayDate);
				bill.setTotal(total);
				bill.setCreatdBy(createdBy);
				BillDao.save(bill);
				
				String path = "C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\billRecord\\";
				com.itextpdf.text.Document doc = new com.itextpdf.text.Document();
				try {
					PdfWriter.getInstance(doc, new FileOutputStream(path + "" +billId+".pdf"));
					doc.open();                         
					Paragraph cafeName = new Paragraph("                                                                     Chordy Cafe\n\n");
					doc.add(cafeName);
					Paragraph starLine = new Paragraph("****************************************************************************************************************");
					doc.add(starLine);
					Paragraph paragraph3 = new Paragraph("\tBill ID: " +billId+"\nTotal Paid: $"+grandTotal+"\nReciptionist: "+createdBy);
					doc.add(paragraph3);
					doc.add(starLine);
					PdfPTable tb1 = new PdfPTable(4);
					tb1.addCell("Name");
					tb1.addCell("Price");
					tb1.addCell("Quantity");
					tb1.addCell("Total");
					for(int i = 0; i<j2.getRowCount(); i++) {
						String n = j2.getValueAt(i, 0).toString();
						String d = j2.getValueAt(i, 1).toString();
						String r = j2.getValueAt(i, 2).toString();
						String q = j2.getValueAt(i, 3).toString();
						tb1.addCell(n);
						tb1.addCell(d);
						tb1.addCell(r);
						tb1.addCell(q);
					}
					doc.add(tb1);
					
					doc.add(starLine);
					Paragraph thanksMsg = new Paragraph("Thank you, Please visit Again.");
					doc.add(thanksMsg);
					OpenPdf.openById(String.valueOf(billId));
				}
				catch (Exception e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				doc.close();
				PlaceOrder(hf, email);
				f.dispose();
				grandTotal = 0;
			}
		});
		btnGenerateBillPrint.setBounds(967, 657, 179, 23);
		f.getContentPane().add(btnGenerateBillPrint);

		txtProName.setEditable(false);
		txtPrice.setEditable(false);
		txtTotal.setEditable(false);
		btnAddToCart.setEnabled(false);
		btnGenerateBillPrint.setEnabled(false);
		
		JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String category = (String) comboBox.getSelectedItem();
				productNameByCategory(category, j);
			}
		});
		comboBox.setBounds(202, 105, 250, 22);
		f.getContentPane().add(comboBox);
		
		f.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentShown(ComponentEvent e) {
				
				billId = Integer.parseInt(BillDao.getId());
				lblBill.setText(""+billId);
				ArrayList<Category> list = CategoryDao.getAllRecords();
				Iterator<Category> itr = list.iterator();
				while(itr.hasNext()) {
					Category categoryObj = itr.next();
					comboBox.addItem(categoryObj.getName());
				}
				String category = (String) comboBox.getSelectedItem();
				productNameByCategory(category, j);
			}
		});

		txtSearch.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				String name = txtSearch.getText();
				String category = (String) comboBox.getSelectedItem();
				DefaultTableModel dtm = (DefaultTableModel) j.getModel();
		        dtm.setRowCount(0);
		        ArrayList<Product> list = ProductDao.filterProductByname(name,category);
		        Iterator<Product> itr = list.iterator();
		        while(itr.hasNext()) {
		        	Product productObj = itr.next();
		        	dtm.addRow(new Object[] {productObj.getName()});
		        }
			}
		});
		
		j.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index = j.getSelectedRow();
				TableModel model = j.getModel();
				String ProductName = model.getValueAt(index, 0).toString();
				Product product = ProductDao.getProductByname(ProductName);
				txtProName.setText(product.getName());
				txtPrice.setText(product.getPrice());
				String price = txtPrice.getText();
				price = price.replace("$", "");
				spinner.setValue(1);
				txtTotal.setText(product.getPrice());
				productPrice = Float.parseFloat(price);
				productTotal = Float.parseFloat(price);
				btnAddToCart.setEnabled(true);
			}
		});

		btnAddToCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = txtProName.getText();
				String price = txtPrice.getText();
				String quantity = String.valueOf(spinner.getValue());
				DefaultTableModel dtm = (DefaultTableModel) j2.getModel();
				dtm.addRow(new Object[] {name,price,quantity,"$"+(productTotal)});
				grandTotal = grandTotal + productTotal;
				lblGrandTotal.setText("$"+String.valueOf(grandTotal));
				clearProductFields(btnAddToCart,spinner);
				btnGenerateBillPrint.setEnabled(true);
			}
		});
		
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PlaceOrder(hf,email);
				Timer timer = new Timer(5000, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        j.setEnabled(true);
                    }
                });
                timer.setRepeats(false);
                timer.start();
				f.dispose();
			}
		});
		
		JLabel lblNewLabel_7 = new JLabel("Bill ID:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_7.setBounds(60, 108, 89, 14);
		f.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("*Click on row to delete");
		lblNewLabel_8.setBounds(774, 631, 237, 14);
		f.getContentPane().add(lblNewLabel_8);

		JFormattedTextField tf = ((JSpinner.DefaultEditor) spinner.getEditor()).getTextField();
		tf.setEnabled(false);
		
		f.setLocation(0,0);
		f.setUndecorated(true);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        f.setSize(1297,768);
        f.setVisible(true);
	}
}
