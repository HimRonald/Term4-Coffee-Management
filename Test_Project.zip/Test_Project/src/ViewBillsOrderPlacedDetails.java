import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import common.OpenPdf;
import dao.BillDao;
import model.Bill;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

public class ViewBillsOrderPlacedDetails {
	private static JTextField textField;
	public static void tableDetails(JTable j, JComboBox combobox) {
		String date = textField.getText();
		String incDec = (String)combobox.getSelectedItem();
		DefaultTableModel dtm = (DefaultTableModel) j.getModel();
		dtm.setRowCount(0);
		if(incDec.equals("Button")) {
			ArrayList<Bill> list = BillDao.getAllRecordsByInc(date);
			Iterator<Bill> itr = list.iterator();
			while(itr.hasNext()) {
				Bill billObj = itr.next();
				dtm.addRow(new Object[] {billObj.getId(), billObj.getDate(), billObj.getTotal(), billObj.getCreatdBy()});
			}
		}
		else {
			ArrayList<Bill> list = BillDao.getAllRecordsByDesc(date);
			Iterator<Bill> itr = list.iterator();
			while(itr.hasNext()) {
				Bill billObj = itr.next();
				dtm.addRow(new Object[] {billObj.getId(), billObj.getDate(), billObj.getTotal(), billObj.getCreatdBy()});
			}
		}
	}
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void ViewBillsOrderPlacedDetails(JFrame hf) {
		JFrame f = new JFrame();
		SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		String todayDate = df.format(date);
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hf.setEnabled(true);
				f.dispose();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\close.png"));
		btnNewButton.setBounds(1240, 11, 30, 30);
		f.getContentPane().add(btnNewButton);
		
		f.getContentPane().setLayout(null);
		
		JLabel lblViewBills = new JLabel("View Bills & Order Placed Details");
		lblViewBills.setFont(new Font("Tahoma", Font.BOLD, 17));
		lblViewBills.setBounds(10, 11, 370, 20);
		f.getContentPane().add(lblViewBills);
		
		JLabel lblNewLabel = new JLabel("Filter By Date");
		lblNewLabel.setBounds(311, 132, 115, 14);
		f.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(399, 129, 171, 20);
		f.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Change Order By ID ");
		lblNewLabel_1.setBounds(624, 132, 124, 14);
		f.getContentPane().add(lblNewLabel_1);
		
		DefaultTableModel header2 = new DefaultTableModel();
		header2.addColumn("ID");
		header2.addColumn("Date");
		header2.addColumn("Total");
		header2.addColumn("Receptionist");
		JTable j2 = new JTable(header2);
		j2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index = j2.getSelectedRow();
				TableModel model = j2.getModel();
				String id = model.getValueAt(index, 0).toString();
				OpenPdf.openById(id);
			}
		});
		j2.setBackground(new Color(255, 255, 255));
        JScrollPane scrollPane2 = new JScrollPane(j2);
        
		scrollPane2.setBounds(10,201,1260,471);
		f.getContentPane().add(scrollPane2);

		JComboBox comboBox = new JComboBox();
		comboBox.addItem("Button");
		comboBox.addItem("Top");
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tableDetails(j2,comboBox);
			}
		});
		comboBox.setBounds(758, 128, 213, 22);
		f.getContentPane().add(comboBox);

		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				tableDetails(j2,comboBox);
			}
		});

		f.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentShown(ComponentEvent e) {
				tableDetails(j2,comboBox);
			}
		});

		textField.setText(todayDate);
		JLabel lblNewLabel_2 = new JLabel("Click On Row To Open Bill");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(519, 703, 271, 38);
		f.getContentPane().add(lblNewLabel_2);
		f.setLocation(0,0);
		f.setUndecorated(true);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        f.setSize(1297,768);
        f.setVisible(true);
	}
}
