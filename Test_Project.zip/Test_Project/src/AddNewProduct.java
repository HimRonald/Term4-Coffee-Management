import javax.swing.*;

import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import model.Category;
import model.Product;
import dao.CategoryDao;
import java.util.Iterator;
import dao.ProductDao;

class AddNewProduct{
	private static JTextField txtName;
	private static JTextField txtPrice;
	
	public static void validateFields(JButton btnSave) {
		String name = txtName.getText();
		String price = txtPrice.getText(); 
		if(!name.equals("") && !price.equals("")) {
			btnSave.setEnabled(true);
		}
		else {
			btnSave.setEnabled(false);
		}
	}
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void AddNewProduct(JFrame hf) {
		JFrame f = new JFrame("Coffee Shop Management System");
		f.setUndecorated(true);
		f.setLocation(new Point(350, 100));
		
		JLabel lblNewLabel = new JLabel("New Product");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 10, 150, 20);
		f.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hf.setEnabled(true);
				f.dispose();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\close.png"));
		btnNewButton.setBounds(460, 11, 30, 30);
		f.getContentPane().add(btnNewButton);
		
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(111, 110, 49, 14);
		f.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Category");
		lblNewLabel_2.setBounds(111, 156, 64, 14);
		f.getContentPane().add(lblNewLabel_2);
		
		JComboBox txtCategory = new JComboBox();
		ArrayList<Category> list = CategoryDao.getAllRecords();
		Iterator<Category> itr = list.iterator();
		while(itr.hasNext()) {
			Category categoryObj = itr.next();
			txtCategory.addItem(categoryObj.getName());
		}
		
		txtCategory.setBounds(189, 152, 225, 22);
		f.getContentPane().add(txtCategory);
		
		JLabel lblNewLabel_3 = new JLabel("Price");
		lblNewLabel_3.setBounds(111, 209, 49, 14);
		f.getContentPane().add(lblNewLabel_3);
		
		txtName = new JTextField();
		txtName.setBounds(189, 107, 225, 20);
		f.getContentPane().add(txtName);
		txtName.setColumns(10);
		
		txtPrice = new JTextField();
		txtPrice.setBounds(189, 206, 225, 20);
		f.getContentPane().add(txtPrice);
		txtPrice.setColumns(10);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product product = new Product();
				product.setName(txtName.getText());
				product.setCategory((String)txtCategory.getSelectedItem());
				product.setPrice(txtPrice.getText());
				ProductDao.save(product);
				AddNewProduct(hf);
				f.dispose();
			}
		});
		btnSave.setBounds(189, 258, 89, 23);
		f.getContentPane().add(btnSave);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddNewProduct(hf);
				f.dispose();
			}
		});
		btnClear.setBounds(325, 258, 89, 23);
		f.getContentPane().add(btnClear);
		

		txtPrice.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnSave);
			}
		});
		txtName.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnSave);
			}
		});
		
		btnSave.setEnabled(false);
		
		JLabel lblNewLabel_4 = new JLabel("\r\n");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\3.png"));
		lblNewLabel_4.setBounds(0, 0, 500, 500);
		f.getContentPane().add(lblNewLabel_4);
		f.setSize(500,500);
		f.setVisible(true);
	}
}