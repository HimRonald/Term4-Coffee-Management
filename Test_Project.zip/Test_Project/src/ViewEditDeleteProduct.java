import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import dao.CategoryDao;
import dao.ProductDao;
import model.Category;
import model.Product;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Point;
public class ViewEditDeleteProduct {
	private static JTextField txtName;
	private static JTextField txtPrice;
	
	public static void validateFields(JButton btnUpdate,JComboBox comboBox ) {
		String name = txtName.getText();
		String price = txtPrice.getText();
		String category = (String)comboBox.getSelectedItem();
		if(!name.equals("") && !price.equals("") && category!=null) {
			btnUpdate.setEnabled(true);
		}
		else {
			btnUpdate.setEnabled(false);
		}
		
	}
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void ViewEditDeleteProduct(JFrame hf) {
		JFrame f = new JFrame("");
		f.setLocation(new Point(300, 85));
		f.getContentPane().setBackground(new Color(229, 217, 205));
		f.setUndecorated(true);
		
		f.setSize(610,530);
		f.getContentPane().setLayout(null);
		
		JLabel lblViewEdit = new JLabel("View, Edit & Delete Product");
		lblViewEdit.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblViewEdit.setBounds(10, 11, 211, 20);
		f.getContentPane().add(lblViewEdit);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hf.setEnabled(true);
				f.dispose();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\close.png"));
		btnNewButton.setBounds(570, 11, 30, 30);
		f.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setBounds(26, 90, 49, 14);
		f.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setBounds(26, 140, 49, 14);
		f.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Category");
		lblNewLabel_2.setBounds(26, 200, 64, 14);
		f.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Price");
		lblNewLabel_3.setBounds(26, 260, 49, 14);
		f.getContentPane().add(lblNewLabel_3);
		
		JLabel lblID = new JLabel("00");
		lblID.setBounds(100, 90, 49, 14);
		f.getContentPane().add(lblID);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(100, 196, 121, 22);
		f.getContentPane().add(comboBox);
		
		txtName = new JTextField();
		txtName.setBounds(100, 137, 121, 20);
		f.getContentPane().add(txtName);
		txtName.setColumns(10);
		
		txtPrice = new JTextField();
		txtPrice.setBounds(100, 257, 121, 20);
		f.getContentPane().add(txtPrice);
		txtPrice.setColumns(10);
		
		JButton btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Product product = new Product();
				int id = Integer.parseInt(lblID.getText());
				product.setId(id);
				product.setName(txtName.getText());
				product.setCategory((String) comboBox.getSelectedItem());
				product.setPrice(txtPrice.getText());
				ProductDao.update(product);
				ViewEditDeleteProduct(hf);
				f.dispose();
			}
		});
		btnUpdate.setBounds(26, 320, 89, 23);
		f.getContentPane().add(btnUpdate);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = lblID.getText();
				int a = JOptionPane.showConfirmDialog(null,"Do you want to Delete this product","Select",JOptionPane.YES_NO_OPTION );
				if(a==0) {
					ProductDao.delete(id);
					ViewEditDeleteProduct(hf);
					f.dispose();
				}
			}
		});
		btnDelete.setBounds(125, 320, 89, 23);
		f.getContentPane().add(btnDelete);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewEditDeleteProduct(hf);
				f.dispose();
			}
		});
		btnClear.setBounds(26, 365, 89, 23);
		f.getContentPane().add(btnClear);
		
		DefaultTableModel header = new DefaultTableModel();
		header.addColumn("ID");
		header.addColumn("Name");
		header.addColumn("Category");
		header.addColumn("Price");
		JTable j = new JTable(header);
		j.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index = j.getSelectedRow();
				TableModel model = j.getModel();
				String id = model.getValueAt(index,0).toString();
				lblID.setText(id);
				String name = model.getValueAt(index, 1).toString();
				txtName.setText(name);
				String category = model.getValueAt(index, 2).toString();
				String price = model.getValueAt(index, 3).toString();
				txtPrice.setText(price);
				
				btnUpdate.setEnabled(true);
				btnDelete.setEnabled(true);
				txtName.setEnabled(true);
				comboBox.setEnabled(true);
				txtPrice.setEnabled(true);
				
				comboBox.removeAllItems();
				comboBox.addItem(category);
				ArrayList<Category> categoryList = CategoryDao.getAllRecords();
				Iterator<Category> categoryItr = categoryList.iterator();
				while(categoryItr.hasNext()) {
					Category categoryObj = categoryItr.next();
					if(!categoryObj.getName().equals(category)) {
						comboBox.addItem(categoryObj.getName());
					}
				}
			}
		});
		j.setBackground(new Color(255, 255, 255));
        JScrollPane scrollPane = new JScrollPane(j);

        scrollPane.setBackground(new Color(255, 255, 255));
		DefaultTableModel model = (DefaultTableModel) j.getModel();
		ArrayList<Product> list = ProductDao.getAllRecords();
		Iterator<Product> itr = list.iterator();
		
		while(itr.hasNext()) {
			Product productObj = itr.next();
			model.addRow(new Object[] {productObj.getId(), productObj.getName(), productObj.getCategory(), productObj.getPrice()});
		}
		
		scrollPane.setBounds(241,89,359,300);
		f.getContentPane().add(scrollPane);
		

		txtName.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnUpdate, comboBox);
			}
		});
		txtPrice.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnUpdate, comboBox);
			}
		});
		
		btnUpdate.setEnabled(false);
		btnDelete.setEnabled(false);
		txtName.setEnabled(false);
		comboBox.setEnabled(false);
		txtPrice.setEnabled(false);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\categoryBackground.png"));
		lblNewLabel_4.setBounds(60, 30, 500, 500);
		f.getContentPane().add(lblNewLabel_4);
		
		
		f.setVisible(true);
	}
}
