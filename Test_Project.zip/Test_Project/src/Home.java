import javax.swing.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class Home {
	public static void Home(String email) {
		JFrame f = new JFrame("Coffee Shop Management System");
		f.getContentPane().setBackground(new Color(229, 217, 205));
		
		f.getContentPane().setLayout(null);
		f.setUndecorated(true);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        f.setSize(screenSize.width, screenSize.height);
		
		JButton btnNewButton = new JButton("Logout");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a = JOptionPane.showConfirmDialog(null, "Do you really want to Logout?","Select",JOptionPane.YES_NO_OPTION);
				if(a==0) {
					Login login = new Login();
					login.Login();
					f.dispose();
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setBounds(60, 40, 90, 40);
		f.getContentPane().add(btnNewButton);
		
		JButton btnPlaceOrder = new JButton("Place Order");
		btnPlaceOrder.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnPlaceOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PlaceOrder po = new PlaceOrder();
				po.PlaceOrder(f,email);
				f.setEnabled(false);
			}
		});
		btnPlaceOrder.setBackground(Color.WHITE);
		btnPlaceOrder.setBounds(200, 40, 139, 40);
		f.getContentPane().add(btnPlaceOrder);
		
		JButton btnViewBills = new JButton("View Bills  & Order Placed Details");
		btnViewBills.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnViewBills.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewBillsOrderPlacedDetails vbop = new ViewBillsOrderPlacedDetails();
				vbop.ViewBillsOrderPlacedDetails(f);
				f.setEnabled(false);
				
			}
		});
		btnViewBills.setBackground(Color.WHITE);
		btnViewBills.setBounds(389, 40, 230, 40);
		f.getContentPane().add(btnViewBills);
		
		JButton btnChangePassword = new JButton("Change Password");
		btnChangePassword.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnChangePassword.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChangePassword cp = new ChangePassword();
				cp.ChangePassword(f, email);
				f.setEnabled(false);
			}
		});
		btnChangePassword.setBackground(Color.WHITE);
		btnChangePassword.setBounds(676, 40, 150, 40);
		f.getContentPane().add(btnChangePassword);
		
		JButton btnChangeSecurityQuestion = new JButton("Change Security Question");
		btnChangeSecurityQuestion.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnChangeSecurityQuestion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChangeSecuriyQuestion csq = new ChangeSecuriyQuestion();
				csq.ChangeSecuriyQuestion(f, email);
				f.setEnabled(false);
			}
		});
		btnChangeSecurityQuestion.setBackground(Color.WHITE);
		btnChangeSecurityQuestion.setBounds(880, 40, 200, 40);
		f.getContentPane().add(btnChangeSecurityQuestion);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a = JOptionPane.showConfirmDialog(null, "Do you really want to close application?","Select",JOptionPane.YES_NO_OPTION);
				if(a==0) {
					System.exit(0);
				}
			}
		});
		btnExit.setBackground(Color.WHITE);
		btnExit.setBounds(1130, 40, 90, 40);
		f.getContentPane().add(btnExit);
		
		JButton btnManageCategory = new JButton("Manage Category");
		btnManageCategory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageCategory mc = new ManageCategory();
				mc.ManageCategory(f);
				f.setEnabled(false);
			}
		});
		btnManageCategory.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnManageCategory.setBackground(Color.WHITE);
		btnManageCategory.setBounds(200, 625, 161, 40);
		f.getContentPane().add(btnManageCategory);
		
		JButton btnNewProduct = new JButton("New Product");
		btnNewProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddNewProduct product = new AddNewProduct();
				product.AddNewProduct(f);
				f.setEnabled(false);
			}
		});
		btnNewProduct.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewProduct.setBackground(Color.WHITE);
		btnNewProduct.setBounds(450, 625, 130, 40);
		f.getContentPane().add(btnNewProduct);
		
		JButton btnViewEdit = new JButton("View, Edit & Delete Product");
		btnViewEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewEditDeleteProduct VEDP = new ViewEditDeleteProduct();
				VEDP.ViewEditDeleteProduct(f);
				f.setEnabled(false);
			}
		});
		btnViewEdit.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnViewEdit.setBackground(Color.WHITE);
		btnViewEdit.setBounds(660, 625, 230, 40);
		f.getContentPane().add(btnViewEdit);
		
		JButton btnVerify = new JButton("Verify");
		btnVerify.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VerifyUser vu = new VerifyUser();
				vu.VerifyUser(f);
				f.setEnabled(false);
			}
		});
		btnVerify.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnVerify.setBackground(Color.WHITE);
		btnVerify.setBounds(970, 625, 90, 40);
		f.getContentPane().add(btnVerify);
		
		f.setSize(1366,768);
		f.setVisible(true);
		
		if(!email.equals("admin@gmail.com")) {
			btnManageCategory.setVisible(false);
			btnNewProduct.setVisible(false);
			btnViewEdit.setVisible(false);
			btnVerify.setVisible(false);
			PlaceOrder po = new PlaceOrder();
			po.PlaceOrder(f,email);
			f.setEnabled(false);
		}
	}
	
	public static void main(String[] args) {
		String email = "admin@gmail.com";
		Home(email);
	}
}
