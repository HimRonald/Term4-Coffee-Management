import javax.swing.*;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.Toolkit;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Point;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.*;

import model.Category;
import dao.CategoryDao;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

class ManageCategory{
	private static JTextField txtName;
	
	public static void validateField(JButton btnSave) {
		String category = txtName.getText();
		if(!category.equals("")) {
			btnSave.setEnabled(true);
		}
		else {
			btnSave.setEnabled(false);
		}
	}
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void ManageCategory(JFrame hf) {
		JFrame f = new JFrame("Coffee Shop Management System");
		f.setUndecorated(true);
		f.setLocation(new Point(350, 100));
		f.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\cafeLogo.jpg"));
		
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Manage Category");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 10, 150, 20);
		f.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hf.setEnabled(true);
				f.dispose();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\close.png"));
		btnNewButton.setBounds(460, 11, 30, 30);
		f.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("View Category");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(301, 48, 105, 17);
		f.getContentPane().add(lblNewLabel_1);
		
		DefaultTableModel header = new DefaultTableModel();
		header.addColumn("ID");
		header.addColumn("Category");
		JTable j = new JTable(header);
		j.setBackground(new Color(255, 255, 255));
        JScrollPane scrollPane = new JScrollPane(j);
        j.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                j.setEnabled(false);
        		Timer timer = new Timer(500, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        j.setEnabled(true);
                    }
                });
                timer.setRepeats(false);
                timer.start();
                if (e.getClickCount() == 2) {
                    int index = j.getSelectedRow();
                    TableModel model = j.getModel();
                    String id = model.getValueAt(index, 0).toString();
                    String name = model.getValueAt(index, 1).toString();
                    int a = JOptionPane.showConfirmDialog(null, "Do you really want to Delete "+name+" Category?","Select",JOptionPane.YES_NO_OPTION);
                    if(a==0) {
                        CategoryDao.delete(id);
                        ManageCategory(hf);
                        f.dispose();
                    }
                }
            }
        });


        scrollPane.setBackground(new Color(255, 255, 255));
		DefaultTableModel model = (DefaultTableModel) j.getModel();
		ArrayList<Category> list = CategoryDao.getAllRecords();
		Iterator<Category> itr = list.iterator();
		
		while(itr.hasNext()) {
			Category categoryObj = itr.next();
			model.addRow(new Object[] {categoryObj.getId(), categoryObj.getName()});
		}
		
		scrollPane.setBounds(223,76,250,300);
		f.getContentPane().add(scrollPane);
		
		JLabel lblNewLabel_2 = new JLabel("*Double click on row to Delete Category");
		lblNewLabel_2.setBounds(233, 387, 240, 20);
		f.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Add New Category");
		lblNewLabel_3.setBounds(55, 138, 130, 14);
		f.getContentPane().add(lblNewLabel_3);
		
		txtName = new JTextField();
		txtName.setBounds(10, 163, 191, 20);
		f.getContentPane().add(txtName);
		txtName.setColumns(10);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Category category = new Category();
				category.setName(txtName.getText());
				CategoryDao.save(category);
				ManageCategory(hf);
				f.dispose();
			}
		});
		btnSave.setBounds(10, 194, 89, 23);
		f.getContentPane().add(btnSave);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageCategory(hf);
				f.dispose();
			}
		});
		btnClear.setBounds(112, 194, 89, 23);
		f.getContentPane().add(btnClear);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\categoryBackground.png"));
		lblNewLabel_4.setBounds(0, 0, 500, 500);
		f.getContentPane().add(lblNewLabel_4);
		
		txtName.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateField(btnSave);
			}
		});
		
		btnSave.setEnabled(false);
		f.setSize(500,500);
		f.setVisible(true);
	}
	
}