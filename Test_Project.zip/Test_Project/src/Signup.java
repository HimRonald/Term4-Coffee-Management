import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;
import model.User;
import dao.UserDao;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Toolkit;

public class Signup{
	private static JTextField txtName;
	private static JTextField txtEmail;
	private static JTextField txtMobileNumber;
	private static JPasswordField passwordField;
	private static JPasswordField cf_passwordField;
	private static JTextField txtSecurity;
	private static JTextField txtAnswer;
	
	public static String emailPattern = "^[a-zA-Z0-9]+[@]+[a-zA-Z0-9]+[.]+[a-zA-Z0-9]+$";
	public static String mobileNumberPattern = "^[0-9]*$";
	
	public static void clear(JButton btnSignUp) {
		txtName.setText("");
		txtEmail.setText("");
		txtMobileNumber.setText("");
		passwordField.setText("");
		cf_passwordField.setText("");
		txtSecurity.setText("");
		txtAnswer.setText("");
		btnSignUp.setEnabled(false);
	}
	
	public static void validateFields(JButton btnSignUp) {
		String name = txtName.getText();
		String email = txtEmail.getText();
		String mobileNumber = txtMobileNumber.getText();
		String password = passwordField.getText();
		String confirm_pw = cf_passwordField.getText();
		String securityQ = txtSecurity.getText();
		String answer = txtAnswer.getText();
		if(!name.equals("") && email.matches(emailPattern) && mobileNumber.matches(mobileNumberPattern) && mobileNumber.length()== 9 && !password.equals("") && !confirm_pw.equals("")&& password.equals(confirm_pw) && !securityQ.equals("") && !answer.equals("") ) {
			btnSignUp.setEnabled(true);
		}
		else {
			btnSignUp.setEnabled(false);
		}
	}
	
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void Signup() {
		JFrame f = new JFrame("Coffee Shop Management System");
		f.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\cafeLogo.jpg"));
		f.getContentPane().setBackground(new Color(255, 255, 255));
		f.getContentPane().setForeground(new Color(0, 0, 0));
		
		f.getContentPane().setLayout(null);
		
		JLabel title = new JLabel("Sign Up");
		title.setFont(new Font("Tahoma", Font.PLAIN, 20));
		title.setBounds(150, 5, 98, 57);
		f.setSize(400,500);
		f.getContentPane().add(title);
		
		JLabel l1 = new JLabel("Name:");
		l1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l1.setBounds(83, 70, 71, 14);
		f.getContentPane().add(l1);
		
		txtName = new JTextField();
		txtName.setBounds(130, 69, 224, 20);
		f.getContentPane().add(txtName);
		txtName.setColumns(10);
		
		JLabel l2 = new JLabel("Email:");
		l2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l2.setBounds(86, 115, 71, 14);
		f.getContentPane().add(l2);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(130, 114, 224, 20);
		f.getContentPane().add(txtEmail);
		
		JLabel l3 = new JLabel("Mobile Number: ");
		l3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l3.setBounds(20, 160, 111, 14);
		f.getContentPane().add(l3);
		
		txtMobileNumber = new JTextField();
		txtMobileNumber.setColumns(10);
		txtMobileNumber.setBounds(130, 159, 224, 20);
		f.getContentPane().add(txtMobileNumber);
		
		JLabel l4 = new JLabel("Password");
		l4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l4.setBounds(58, 205, 111, 14);
		f.getContentPane().add(l4);
		
		JLabel l5 = new JLabel("Confirm Password");
		l5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l5.setBounds(2, 250, 140, 14);
		f.getContentPane().add(l5);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(130, 204, 224, 20);
		f.getContentPane().add(passwordField);
		
		cf_passwordField = new JPasswordField();
		cf_passwordField.setBounds(130, 249, 224, 20);
		f.getContentPane().add(cf_passwordField);
		
		JLabel l6 = new JLabel("Security Question:");
		l6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l6.setBounds(4, 293, 140, 20);
		f.getContentPane().add(l6);
		
		txtSecurity = new JTextField();
		txtSecurity.setColumns(10);
		txtSecurity.setBounds(130, 294, 224, 20);
		f.getContentPane().add(txtSecurity);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBackground(new Color(255, 255, 255));
		btnCancel.setBounds(130, 385, 101, 38);
		f.getContentPane().add(btnCancel);
		
		JButton btnSignUp = new JButton("Sign Up");
		btnSignUp.setBackground(new Color(255, 255, 255));
		btnSignUp.setBounds(253, 385, 101, 38);
		f.getContentPane().add(btnSignUp);
		
		JLabel l7 = new JLabel("Answer:");
		l7.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l7.setBounds(71, 337, 81, 20);
		f.getContentPane().add(l7);
		
		txtAnswer = new JTextField();
		txtAnswer.setColumns(10);
		txtAnswer.setBounds(130, 339, 224, 20);

		txtName.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnSignUp);
			}
		});
		txtEmail.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnSignUp);
			}
		});
		txtMobileNumber.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnSignUp);
			}
		});
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnSignUp);
			}
		});
		cf_passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnSignUp);
			}
		});
		txtSecurity.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnSignUp);
			}
		});
		txtAnswer.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnSignUp);
			}
		});
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a = JOptionPane.showConfirmDialog(null,"Do you really want to cancel signing up?", "Select",JOptionPane.YES_NO_OPTION);
				if (a == 0) {
					Login login = new Login();
					login.Login();
					f.dispose();
				}
			}
		});
		btnCancel.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnCancel.setForeground(Color.RED);
            }
            public void mouseExited(MouseEvent e) {
                btnCancel.setForeground(Color.BLACK);
            }
        });
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				User user = new User();
				user.setName(txtName.getText());
				user.setEmail(txtEmail.getText());
				user.setMobileNumber(txtMobileNumber.getText());
				user.setPassword(passwordField.getText());
				user.setConfirm_pw(cf_passwordField.getText());
				user.setSecurityQ(txtSecurity.getText());
				user.setAnswer(txtAnswer.getText());
				UserDao.save(user);
				clear(btnSignUp);
			}
		});
		btnSignUp.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnSignUp.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e) {
                btnSignUp.setForeground(Color.BLACK);
            }
        });
		
		btnSignUp.setEnabled(false);
		
		f.getContentPane().add(txtAnswer);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\LoginBackground.png"));
		lblNewLabel.setBounds(0, 0, 500, 500);
		f.getContentPane().add(lblNewLabel);
		f.setResizable(false);
		f.setVisible(true);
	}
	public static void main(String[] args) {
		Signup();
	}

}