import java.awt.Color;
import java.awt.Font;

import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import model.User;
import dao.UserDao;
import java.awt.Toolkit;

public class ForgotPassword {
	public static String email = null;
	public static String dbAnswer = null;
	public static String emailPattern = "^[a-zA-Z0-9]+[@]+[a-zA-Z0-9]+[.]+[a-zA-Z0-9]+$";
	
	private static JTextField txtEmail;
	private static JPasswordField newPasswordField;
	private static JPasswordField cf_newPasswordField;
	private static JTextField txtSecurity;
	private static JTextField txtAnswer;
	
	public static void clear(JButton btnContinue, JButton btnSearch) {
		txtEmail.setEditable(true);
		txtEmail.setText("");
		newPasswordField.setText("");
		cf_newPasswordField.setText("");
		txtSecurity.setText("");
		txtAnswer.setText("");
		btnContinue.setEnabled(false);
		btnSearch.setEnabled(false);
	}
	public static void validateEmail(JButton btnSearch) {
		email = txtEmail.getText();
		if(email.matches(emailPattern)) {
			btnSearch.setEnabled(true);
		}
		else {
			btnSearch.setEnabled(false);
		}
	}
	public static void validateFields(JButton btnContinue) {
		String newPassword = newPasswordField.getText();
		String confirm_npw = cf_newPasswordField.getText();
		String answer = txtAnswer.getText();
		String securityQ = txtSecurity.getText();
		if(!newPassword.equals("") && !answer.equals("") && !securityQ.equals("") &&newPassword.equals(confirm_npw)) {

			btnContinue.setEnabled(true);
		}
		else {
			btnContinue.setEnabled(false);
		}
	}
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void ForgotPassword(){
		JFrame frame = new JFrame("Coffee Shop Management System");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\cafeLogo.jpg"));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
		
		JLabel title = new JLabel("Forgot Password");
		title.setFont(new Font("Tahoma", Font.PLAIN, 20));
		title.setBounds(125, 5, 200, 57);
		frame.setSize(400,500);
		frame.getContentPane().add(title);
		
		JLabel l2 = new JLabel("Email:");
		l2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l2.setBounds(86, 70, 71, 14);
		frame.getContentPane().add(l2);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(130, 69, 224, 20);
		frame.getContentPane().add(txtEmail);
		
		JLabel l4 = new JLabel("New Password");
		l4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l4.setBounds(22, 205, 111, 14);
		frame.getContentPane().add(l4);
		
		JLabel l5 = new JLabel("Confirm Password");
		l5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l5.setBounds(2, 250, 140, 14);
		frame.getContentPane().add(l5);
		
		newPasswordField = new JPasswordField();
		newPasswordField.setBounds(130, 204, 224, 20);
		frame.getContentPane().add(newPasswordField);
		
		cf_newPasswordField = new JPasswordField();
		cf_newPasswordField.setBounds(130, 249, 224, 20);
		frame.getContentPane().add(cf_newPasswordField);
		
		JLabel l6 = new JLabel("Security Question:");
		l6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l6.setBounds(4, 115, 140, 20);
		frame.getContentPane().add(l6);
		
		txtSecurity = new JTextField();
		txtSecurity.setColumns(10);
		txtSecurity.setBounds(130, 114, 224, 20);
		frame.getContentPane().add(txtSecurity);
		
		JLabel l7 = new JLabel("Answer:");
		l7.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l7.setBounds(71, 160, 81, 20);
		frame.getContentPane().add(l7);
		
		txtAnswer = new JTextField();
		txtAnswer.setColumns(10);
		txtAnswer.setBounds(130, 159, 224, 20);
		frame.getContentPane().add(txtAnswer);

		JButton btnBack = new JButton("Back");
		btnBack.setBackground(new Color(255, 255, 255));
		btnBack.setBounds(10, 304, 101, 38);
		frame.getContentPane().add(btnBack);
		
		JButton btnContinue = new JButton("Continue");
		btnContinue.setBackground(new Color(255, 255, 255));
		btnContinue.setBounds(253, 304, 101, 38);
		frame.getContentPane().add(btnContinue);
		
		JButton btnSearch = new JButton("Search Email");
		btnSearch.setBackground(Color.WHITE);
		btnSearch.setBounds(126, 304, 117, 38);
		frame.getContentPane().add(btnSearch);
		
		txtEmail.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateEmail(btnSearch);
			}
		});
		newPasswordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnContinue);
			}
		});

		txtSecurity.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnContinue);
			}
		});
		cf_newPasswordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnContinue);
			}
		});
		txtAnswer.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnContinue);
			}
		});
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login login = new Login();
				login.Login();
				frame.dispose();
			}
		});

		btnContinue.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String answer = txtAnswer.getText();
				String newPassword = newPasswordField.getText();
				if(answer.equals(dbAnswer)) {
					UserDao.update(email, newPassword);
					clear(btnContinue, btnSearch);
				}else {
					JOptionPane.showMessageDialog(null, "<html><b style=\"color:red\">Incorrect Answer</b></html>");
				}
			}
		});
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email = txtEmail.getText();
				User user = null;
				user = UserDao.getSecurityQ(email);
				if(user == null) {
					JOptionPane.showMessageDialog(null, "<html><b style=\"color:red\">Incorrect Email</b></html>");
				}
				else {
					btnSearch.setEnabled(false);
					txtEmail.setEditable(false);
					dbAnswer = user.getAnswer();
					txtSecurity.setText(user.getSecurityQ());
					validateFields(btnContinue);
				}
			}
		});

		btnSearch.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnSearch.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e) {
                btnSearch.setForeground(Color.BLACK);
            }
        });
		btnContinue.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnContinue.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e) {
                btnContinue.setForeground(Color.BLACK);
            }
        });
		btnBack.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnBack.setForeground(Color.RED);
            }
            public void mouseExited(MouseEvent e) {
                btnBack.setForeground(Color.BLACK);
            }
        });
		btnContinue.setEnabled(false);
		btnSearch.setEnabled(false);
		txtSecurity.setEditable(false);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\LoginBackground.png"));
		lblNewLabel.setBounds(0, 0, 500, 500);
		frame.getContentPane().add(lblNewLabel);
		
        frame.setVisible(true);
		frame.setSize(400,470);
	}
	public static void main(String[] args) {
		ForgotPassword();
	}
}
