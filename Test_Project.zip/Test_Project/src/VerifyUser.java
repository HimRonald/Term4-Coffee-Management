import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import dao.CategoryDao;
import dao.UserDao;
import model.User;

import java.awt.Font;
import java.awt.Point;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class VerifyUser {
	private static JTextField txtEmail;
	static String email = "";
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void VerifyUser(JFrame hf) {
		JFrame f = new JFrame();
		f.setUndecorated(true);
		
		f.setSize(800,530);
		f.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Verify");
		lblNewLabel.setToolTipText("");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 11, 66, 28);
		f.getContentPane().add(lblNewLabel);

		txtEmail = new JTextField();
		txtEmail.setToolTipText("Input Email");
		txtEmail.setBounds(228, 55, 260, 20);
		f.getContentPane().add(txtEmail);
		txtEmail.setColumns(10);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hf.setEnabled(true);
				f.dispose();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\close.png"));
		btnNewButton.setBounds(760, 9, 30, 30);
		f.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Search");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(172, 57, 46, 14);
		f.getContentPane().add(lblNewLabel_1);
		
		DefaultTableModel header = new DefaultTableModel();
		header.addColumn("ID");
		header.addColumn("Name");
		header.addColumn("Email");
		header.addColumn("Mobile Number");
		header.addColumn("Security Question");
		header.addColumn("Status");
		JTable j = new JTable(header);
		DefaultTableModel dtm = (DefaultTableModel) j.getModel();
		dtm.setRowCount(0);
		ArrayList<User> list = UserDao.getAllRecords(email);
		Iterator<User> itr = list.iterator();
		while(itr.hasNext()) {
			User userObj = itr.next();
			if(!userObj.getEmail().equals("admin@gmail.com")) {
				dtm.addRow(new Object[] {userObj.getId(), userObj.getName(), userObj.getEmail(), userObj.getMobileNumber(), userObj.getSecurityQ(), userObj.getStatus()});
			}
		}
		j.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                j.setEnabled(false);
        		Timer timer = new Timer(500, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        j.setEnabled(true);
                    }
                });
                timer.setRepeats(false);
                timer.start();
                if (e.getClickCount() == 2) {
                    int index = j.getSelectedRow();
                    TableModel model = j.getModel();
                    String email = model.getValueAt(index, 2).toString();
                    String status = model.getValueAt(index, 5).toString();
                    if(status.equals("true")) {
                        status = "false";
                    }
                    else {
                    	status = "true";
                    }
                    int a = JOptionPane.showConfirmDialog(null, "Do you really want to change status of "+email+"?","Select",JOptionPane.YES_NO_OPTION);
                    if(a==0) {
                    	UserDao.changeStatus(email, status);
                    	VerifyUser(hf);
                    	f.dispose();
                    }
                }
            }
        });
        JScrollPane scrollPane = new JScrollPane(j);
		scrollPane.setBounds(10,89,780,383);
		f.getContentPane().add(scrollPane);
		
		
		JLabel lblNewLabel_2 = new JLabel("Double Click On Row To Change Status");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(248, 483, 462, 36);
		f.getContentPane().add(lblNewLabel_2);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setBackground(new Color(255, 255, 255));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				email = txtEmail.getText();
				VerifyUser(hf);
				f.dispose();
			}
		});

		f.setLocation(new Point(235, 87));
		System.out.print(email);
		btnSearch.setBounds(498, 54, 89, 23);
		f.getContentPane().add(btnSearch);
		f.setVisible(true);
	}
}
