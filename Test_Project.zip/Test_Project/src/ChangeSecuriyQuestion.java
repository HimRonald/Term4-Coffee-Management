import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.*;

import dao.UserDao;
import model.User;

import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.Color;

public class ChangeSecuriyQuestion {
	static String userEmail;
	private static JPasswordField passwordField;
	private static JTextField txtOSQ;
	private static JTextField txtNSQ;
	private static JTextField txtAnswer;
	public static void validateField(JButton btnUpdate) {
		String password =passwordField.getText();
		String securityQuestion = txtNSQ.getText();
		String answer = txtAnswer.getText();
		if(!password.equals("") && !securityQuestion.equals("") && !answer.equals("")) {
			btnUpdate.setEnabled(true);
		}
		else {
			btnUpdate.setEnabled(false);
		}
	}
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void ChangeSecuriyQuestion(JFrame hf, String email) {
		JFrame f = new JFrame();
		f.addComponentListener(new ComponentAdapter() {
			@Override
			public void componentShown(ComponentEvent e) {
				User user = UserDao.getSecurityQ(userEmail);
				txtOSQ.setText(user.getSecurityQ());
			}
		});
		f.setUndecorated(true);

		f.getContentPane().setLayout(null);
		
		JLabel lblChangePassword = new JLabel("Change Security Question");
		lblChangePassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangePassword.setBounds(89, 31, 255, 57);
		f.getContentPane().add(lblChangePassword);

		JButton btnUpdate = new JButton("Update");
		btnUpdate.setBackground(new Color(255, 255, 255));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String password =passwordField.getText();
				String securityQuestion = txtNSQ.getText();
				String answer = txtAnswer.getText();
				UserDao.changeSecuriyQuestion(email, password, securityQuestion, answer);
				ChangeSecuriyQuestion(hf, email);
				f.dispose();
			}
		});
		btnUpdate.setBounds(301, 369, 89, 36);
		f.getContentPane().add(btnUpdate);
		
		JLabel lblNewPassword = new JLabel("New Security Question:");
		lblNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewPassword.setBounds(6, 184, 163, 20);
		f.getContentPane().add(lblNewPassword);
		
		JLabel lblComfirPassword = new JLabel("New Answer:");
		lblComfirPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblComfirPassword.setBounds(70, 245, 145, 14);
		f.getContentPane().add(lblComfirPassword);
		
		JLabel lblOldPassword = new JLabel("Old Security Question:");
		lblOldPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblOldPassword.setBounds(13, 126, 156, 20);
		f.getContentPane().add(lblOldPassword);
		
		
		JButton btnNewButton_1 = new JButton("Refresh");
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChangeSecuriyQuestion(hf,email);
				f.dispose();
			}
		});
		btnNewButton_1.setBounds(166, 369, 89, 36);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hf.setEnabled(true);
				f.dispose();
			}
		});
		
		
		btnNewButton_2.setBounds(27, 369, 89, 36);
		f.getContentPane().add(btnNewButton_2);
		
		JLabel lblOldPassword_1 = new JLabel("Password:");
		lblOldPassword_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblOldPassword_1.setBounds(89, 302, 111, 14);
		f.getContentPane().add(lblOldPassword_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(166, 296, 224, 30);
		f.getContentPane().add(passwordField);
		
		txtOSQ = new JTextField();
		txtOSQ.setBounds(166, 123, 224, 30);
		f.getContentPane().add(txtOSQ);
		txtOSQ.setColumns(10);
		
		txtNSQ = new JTextField();
		txtNSQ.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateField(btnUpdate);
			}
		});
		txtNSQ.setColumns(10);
		txtNSQ.setBounds(166, 181, 224, 30);
		f.getContentPane().add(txtNSQ);
		
		txtAnswer = new JTextField();
		txtAnswer.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {

				validateField(btnUpdate);
			}
		});
		txtAnswer.setColumns(10);
		txtAnswer.setBounds(166, 239, 224, 30);
		f.getContentPane().add(txtAnswer);
		
		txtOSQ.setEditable(false);
		userEmail = email;
		btnUpdate.setEnabled(false);
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateField(btnUpdate);
			}
		});
		
		f.setLocation(405, 125);
		f.setSize(400,470);
        f.setVisible(true);
	}
}
