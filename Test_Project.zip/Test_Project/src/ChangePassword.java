import javax.swing.*;

import dao.UserDao;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Color;

public class ChangePassword {
	private static JPasswordField txtOldPassword;
	private static JPasswordField txtNewPassword;
	private static JPasswordField txtConfirm;
	public static String userEmail;
	
	public static void validateField(JButton btnUpdate) {
		String oldPassword = txtOldPassword.getText();
		String newPassword = txtNewPassword.getText();
		String confirmPassword = txtConfirm.getText();
		if(!oldPassword.equals("") && !newPassword.equals("") && !confirmPassword.equals("") && newPassword.equals(confirmPassword)) {
			btnUpdate.setEnabled(true);
		}
		else {
			btnUpdate.setEnabled(false);
		}
	}
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void ChangePassword(JFrame hf, String email) {
		JFrame f = new JFrame();
		f.setUndecorated(true);
		
		f.getContentPane().setLayout(null);

		JLabel lblChangePassword = new JLabel("Change Password");
		lblChangePassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblChangePassword.setBounds(120, 32, 184, 57);
		f.getContentPane().add(lblChangePassword);

		JButton btnUpdate = new JButton("Update");
		btnUpdate.setBackground(new Color(255, 255, 255));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String oldPassword = txtOldPassword.getText();
				String newPassword = txtNewPassword.getText();
				String confirmPassword = txtConfirm.getText();
				UserDao.chnagePassword(email, oldPassword, newPassword);
				ChangePassword(hf, email);
				f.dispose();
			}
		});
		btnUpdate.setBounds(284, 361, 89, 36);
		f.getContentPane().add(btnUpdate);
		txtOldPassword = new JPasswordField();
		txtOldPassword.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateField(btnUpdate);
			}
		});
		txtOldPassword.setBounds(150, 123, 224, 30);
		f.getContentPane().add(txtOldPassword);
		
		txtNewPassword = new JPasswordField();
		txtNewPassword.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateField(btnUpdate);
			}
		});
		txtNewPassword.setBounds(150, 195, 224, 30);
		f.getContentPane().add(txtNewPassword);
		
		txtConfirm = new JPasswordField();
		txtConfirm.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateField(btnUpdate);
			}
		});
		txtConfirm.setBounds(150, 268, 224, 30);
		f.getContentPane().add(txtConfirm);
		
		JLabel lblNewPassword = new JLabel("New Password:");
		lblNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewPassword.setBounds(17, 201, 111, 14);
		f.getContentPane().add(lblNewPassword);
		
		JLabel lblComfirPassword = new JLabel("Comfirm Password:");
		lblComfirPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblComfirPassword.setBounds(17, 274, 145, 14);
		f.getContentPane().add(lblComfirPassword);
		
		JLabel lblOldPassword = new JLabel("Old Password:");
		lblOldPassword.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblOldPassword.setBounds(17, 129, 111, 14);
		f.getContentPane().add(lblOldPassword);
		
		
		JButton btnNewButton_1 = new JButton("Refresh");
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ChangePassword(hf, email);
				f.dispose();
			}
		});
		btnNewButton_1.setBounds(151, 361, 89, 36);
		f.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				hf.setEnabled(true);
				f.dispose();
			}
		});
		
		userEmail = email;
		btnUpdate.setEnabled(false);
		
		btnNewButton_2.setBounds(17, 361, 89, 36);
		f.setLocation(425, 125);
		f.getContentPane().add(btnNewButton_2);
		f.setSize(400,470);
        f.setVisible(true);
	}
}
