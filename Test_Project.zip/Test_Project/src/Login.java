import javax.swing.*;

import dao.UserDao;
import model.User;
import javax.swing.ImageIcon;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Login {

	private static JTextField txtEmail;
	private static JPasswordField passwordField;

	public static String emailPattern = "^[a-zA-Z0-9]+[@]+[a-zA-Z0-9]+[.]+[a-zA-Z0-9]+$";
	
	public static void clear(JButton btnSignUp) {
		txtEmail.setText("");
		passwordField.setText("");
		btnSignUp.setEnabled(false);
	}
	
	public static void validateFields(JButton btnLogin) {
		String email = txtEmail.getText();
		String password = passwordField.getText();
		if(email.matches(emailPattern) && !password.equals("")) {
			btnLogin.setEnabled(true);
		}
		else {
			btnLogin.setEnabled(false);
		}
	}
	/**
	 * @wbp.parser.entryPoint
	 */
	public static void Login() {
		JFrame frame = new JFrame();
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\cafeLogo.jpg"));
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.getContentPane().setLayout(null);
//		frame.setUndecorated(true);
//        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
//        frame.setSize(screenSize.width, screenSize.height);
		
		JLabel title = new JLabel("Login");
		title.setFont(new Font("Tahoma", Font.PLAIN, 20));
		title.setBounds(150, 5, 98, 57);
		frame.getContentPane().add(title);
		
		JLabel l2 = new JLabel("Email:");
		l2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l2.setBounds(40, 100, 71, 14);
		frame.getContentPane().add(l2);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(88, 89, 250, 40);
		frame.getContentPane().add(txtEmail);
		
		JLabel l4 = new JLabel("Password");
		l4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		l4.setBounds(12, 175, 111, 14);
		frame.getContentPane().add(l4);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(88, 164, 250, 40);
		frame.getContentPane().add(passwordField);
		
		JButton btnClose = new JButton("Close");
		btnClose.setBackground(new Color(255, 255, 255));
		btnClose.setBounds(50, 307, 90, 30);
		frame.getContentPane().add(btnClose);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBackground(new Color(255, 255, 255));
		btnLogin.setBounds(237, 240, 101, 38);
		frame.getContentPane().add(btnLogin);
		
		JButton btnForgot = new JButton("Forgot Password");
		btnForgot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ForgotPassword forgot = new ForgotPassword();
				forgot.ForgotPassword();
				frame.dispose();
			}
		});
		btnForgot.setBackground(Color.WHITE);
		btnForgot.setBounds(188, 307, 150, 30);
		frame.getContentPane().add(btnForgot);
		
		JButton btnSignUp = new JButton("Sign Up");
		btnSignUp.setBackground(Color.WHITE);
		btnSignUp.setBounds(50, 240, 101, 38);
		frame.getContentPane().add(btnSignUp);
		
		txtEmail.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnLogin);
			}
		});
		passwordField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				validateFields(btnLogin);
			}
		});
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a = JOptionPane.showConfirmDialog(null,"Do you really want to close the application?", "Select",JOptionPane.YES_NO_OPTION);
				if (a == 0) {
				    System.exit(0);
				}
			}
		});
		btnClose.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnClose.setForeground(Color.RED);
            }
            public void mouseExited(MouseEvent e) {
                btnClose.setForeground(Color.BLACK);
            }
        });
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String email = txtEmail.getText();
				String password = passwordField.getText();
				User user = null ;
				user = UserDao.login(email, password);
				if(user == null) {
					JOptionPane.showMessageDialog(null, "<html><b style=\"color:red\">Incorrect Email or Password</b></html>","Message", JOptionPane.ERROR_MESSAGE);
				}
				else {
					if(user.getStatus().equals("false")) {
						ImageIcon icon = new ImageIcon("src/popupicon/wait.png");
						JOptionPane.showMessageDialog(null,"<html><b style=\\\"color:red\\\">Wait For Admin Approval</b></html>","Message", JOptionPane.INFORMATION_MESSAGE, icon);
						clear(btnLogin);
					}
					else if(user.getStatus().equals("true")) {
						 Home home = new Home();
						 home.Home(email);
						 frame.dispose();
					}
				}
			}
		});
		btnLogin.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnLogin.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e) {
                btnLogin.setForeground(Color.BLACK);
            }
        });
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Signup signup = new Signup();
				signup.Signup();
				frame.dispose();
			}
		});
		btnSignUp.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnSignUp.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e) {
                btnSignUp.setForeground(Color.BLACK);
            }
        });
		btnForgot.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnForgot.setForeground(Color.BLUE);
            }
            public void mouseExited(MouseEvent e) {
                btnForgot.setForeground(Color.BLACK);
            }
        });
		
		btnLogin.setEnabled(false);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Ken\\eclipse-workspace\\Test_Project\\src\\images\\LoginBackground.png"));
		lblNewLabel.setBounds(0, 0, 500, 500);
		frame.getContentPane().add(lblNewLabel);
		
        frame.setVisible(true);
		frame.setSize(400,470);
		
	}
	
	public static void main(String[] args) {
		Login();
	}
}
