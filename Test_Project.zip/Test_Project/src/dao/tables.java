package dao;

import javax.swing.JOptionPane;

public class tables {
	public static void main(String[] agrs) {
		try {
			String userTable = "create table user(id int AUTO_INCREMENT primary key,name varchar(200), email varchar(200), mobileNumber varchar(9), password varchar(200), confirm_pw varchar(200), securityQ varchar(200), answer varchar(200), status varchar(20), UNIQUE (email))";
			DbOperations.setDataOrDelete(userTable, "User Table Created Successfully");
			String categoryTable = "create table category(id int AUTO_INCREMENT primary key, name varchar(200))";
			DbOperations.setDataOrDelete(categoryTable, "Category Table Created Successfully");
			String productTable = "create table product(id int AUTO_INCREMENT primary key, name varchar(200), category varchar(200), price varchar(200))";
			DbOperations.setDataOrDelete(productTable, "Product Table Created Successfully");
			String billTable = "create table bill(id int AUTO_INCREMENT primary key, name varchar(200), date varchar(50), total varchar(200), createdyBy varchar(200))";
			DbOperations.setDataOrDelete(billTable, "Bill Table Created Successfully");
		}
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
	}
}
